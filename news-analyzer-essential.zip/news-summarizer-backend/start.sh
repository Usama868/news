#!/bin/bash
source venv/bin/activate
python src/main.py
